from datetime import date
from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QFormLayout, QComboBox, QLineEdit,
    QPushButton, QListWidget, QListWidgetItem, QMessageBox, QLabel, QTextEdit
)
from models.repositories import PacienteRepo, LookupRepo, ClinicaRepo, ModeloRepo, DocumentoRepo
from services.template_engine import render_template
from services.pdf_service import html_to_pdf
from config import DOCS_DIR, ASSETS_DIR
from pathlib import Path

class PlanPage(QWidget):
    """
    Orçamento/Plano de Tratamento (Planejamento de Custos)
    - Seleciona paciente
    - Adiciona procedimentos (catálogo) + valor
    - Opção de tratamento, forma de pagamento (combo + detalhes)
    - Gera PDF conforme Anexo II
    """
    def __init__(self, paciente_repo: PacienteRepo, lookup_repo: LookupRepo, clinica_repo: ClinicaRepo, parent=None):
        super().__init__(parent)
        self.pacientes = paciente_repo
        self.lookups = lookup_repo
        self.clinica = clinica_repo
        self._build()

    def _build(self):
        root = QHBoxLayout(self)

        left = QVBoxLayout()
        self.cb_paciente = QComboBox(); self._load_pacientes(); left.addWidget(self.cb_paciente)
        self.cb_proc = QComboBox(); self._load_procedimentos(); left.addWidget(self.cb_proc)

        form = QFormLayout()
        self.ed_valor = QLineEdit(); self.ed_valor.setPlaceholderText("Ex.: 150.00")
        form.addRow("Valor (R$)", self.ed_valor)

        self.ed_opcao_trat = QLineEdit()
        form.addRow("Opção de tratamento", self.ed_opcao_trat)

        self.cb_forma_pag = QComboBox()
        self.cb_forma_pag.addItems(["PIX", "Crédito", "Débito", "Dinheiro", "Boleto"])
        form.addRow("Forma de pagamento", self.cb_forma_pag)

        self.ed_forma_pag_obs = QTextEdit(); self.ed_forma_pag_obs.setPlaceholderText("Detalhes/parcelas, vencimentos etc.")
        form.addRow("Detalhes da forma de pagamento", self.ed_forma_pag_obs)

        left.addLayout(form)

        btns = QHBoxLayout()
        self.btn_add = QPushButton("Adicionar Procedimento"); btns.addWidget(self.btn_add)
        self.btn_del = QPushButton("Remover Selecionado"); btns.addWidget(self.btn_del)
        left.addLayout(btns)

        self.list = QListWidget()
        left.addWidget(self.list, 1)

        total_line = QHBoxLayout()
        total_line.addWidget(QLabel("TOTAL (R$):"))
        self.lb_total = QLabel("0.00")
        font = self.lb_total.font(); font.setBold(True); self.lb_total.setFont(font)
        total_line.addWidget(self.lb_total); total_line.addStretch()
        left.addLayout(total_line)

        right = QVBoxLayout()
        self.btn_pdf = QPushButton("Gerar Orçamento/Plano (PDF)")
        right.addWidget(self.btn_pdf)
        right.addStretch()

        root.addLayout(left, 3)
        root.addLayout(right, 1)

        self.btn_add.clicked.connect(self._add_item)
        self.btn_del.clicked.connect(self._del_item)
        self.btn_pdf.clicked.connect(self._generate)
        self.cb_paciente.currentIndexChanged.connect(self._enable_states)
        self.cb_proc.currentIndexChanged.connect(self._enable_states)

        self._enable_states()

    def _load_pacientes(self):
        self.cb_paciente.clear()
        rows = self.pacientes.listar_todos()
        if not rows:
            self.cb_paciente.addItem('Cadastre pacientes na aba "Pacientes"', None)
            return
        for p in rows:
            self.cb_paciente.addItem(p['nome'], p)

    def _load_procedimentos(self):
        self.cb_proc.clear()
        procs = self.lookups.listar_por_tipo('procedimento')
        if not procs:
            self.cb_proc.addItem('Cadastre procedimentos em "Catálogos → Procedimento"', None)
            return
        for it in procs:
            label = f"{it['codigo']} - {it['descricao']}" if it['codigo'] else it['descricao']
            self.cb_proc.addItem(label, it)

    def _recalc_total(self):
        total = 0.0
        for i in range(self.list.count()):
            txt = self.list.item(i).text()
            parts = txt.split("|")
            if len(parts) == 3:
                try:
                    total += float(parts[2])
                except:
                    pass
        self.lb_total.setText(f"{total:.2f}")

    def _collect_items(self):
        out = []
        for i in range(self.list.count()):
            code, desc, val = self.list.item(i).text().split("|")
            out.append({"codigo": code, "procedimento": desc, "valor": float(val)})
        return out

    def _enable_states(self):
        has_paciente = isinstance(self.cb_paciente.currentData(), dict)
        has_proc = isinstance(self.cb_proc.currentData(), dict)
        self.btn_add.setEnabled(has_proc)
        self.btn_pdf.setEnabled(has_paciente and self.list.count() > 0)

    def _add_item(self):
        pr = self.cb_proc.currentData()
        if not isinstance(pr, dict):
            QMessageBox.information(self, "Procedimentos",
                                    'Cadastre procedimentos em "Catálogos → Procedimento" antes de adicionar.')
            return
        valor_text = (self.ed_valor.text().strip() or "0").replace(",", ".")
        try:
            v = float(valor_text)
        except:
            QMessageBox.warning(self, "Valor inválido", "Informe um valor numérico (ex.: 150.00).")
            return
        label = f"{pr.get('codigo','')}|{pr.get('descricao','')}|{v:.2f}"
        self.list.addItem(QListWidgetItem(label))
        self.ed_valor.clear()
        self._recalc_total()
        self._enable_states()

    def _del_item(self):
        r = self.list.currentRow()
        if r >= 0:
            self.list.takeItem(r)
            self._recalc_total()
            self._enable_states()

    def _generate(self):
        paciente = self.cb_paciente.currentData()
        if not isinstance(paciente, dict):
            QMessageBox.warning(self, "Atenção", "Selecione um paciente válido.")
            return
        if self.list.count() == 0:
            QMessageBox.warning(self, "Atenção", "Adicione ao menos um procedimento.")
            return

        mrepo, drepo = ModeloRepo(), DocumentoRepo()

        # usa orcamento.html (novo layout Anexo II)
        with open(ASSETS_DIR / "templates" / "orcamento.html", "r", encoding="utf-8") as f:
            tpl = f.read()
        mid = None  # registro no banco sem vincular a um modelo db específico

        clinica = self.clinica.get()
        itens = self._collect_items()
        total = sum(i["valor"] for i in itens)
        ctx = {
            "paciente": paciente or {},
            "clinica": clinica or {},
            "extras": {
                "itens": itens,
                "total": f"{total:.2f}",
                "opcao_tratamento": self.ed_opcao_trat.text().strip(),
                "forma_pagamento": self.cb_forma_pag.currentText(),
                "forma_pagamento_obs": self.ed_forma_pag_obs.toPlainText().strip()
            },
            "hoje": date.today().strftime("%d/%m/%Y"),
        }
        html = render_template(tpl, ctx)
        out = Path(DOCS_DIR) / f"orcamento_{paciente['nome'].replace(' ','_')}_{date.today().isoformat()}.pdf"
        html_to_pdf(html, out)
        drepo.add(paciente_id=paciente['id'], modelo_id=mid, parametros=ctx['extras'], caminho_pdf=str(out), data_criacao=date.today().isoformat())
        QMessageBox.information(self, "Sucesso", f"PDF gerado em:\n{out}")
