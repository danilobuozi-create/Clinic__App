import json
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QTextEdit, QLineEdit, QLabel, QMessageBox, QFileDialog
from models.repositories import ModeloRepo
from config import ASSETS_DIR

class TemplatesPage(QWidget):
    def __init__(self, modelo_repo: ModeloRepo, parent=None):
        super().__init__(parent)
        self.repo = modelo_repo
        self._selected_id = None
        self._build_ui()
        self._load()

    def _build_ui(self):
        root = QHBoxLayout(self)
        left = QVBoxLayout()
        self.btn_new = QPushButton("Novo")
        self.btn_del = QPushButton("Excluir")
        self.list = QListWidget()
        left.addWidget(self.btn_new)
        left.addWidget(self.btn_del)
        left.addWidget(self.list, 1)

        right = QVBoxLayout()
        self.ed_nome = QLineEdit()
        self.ed_meta = QTextEdit()
        self.tx_html = QTextEdit()
        right.addWidget(QLabel("Nome do Modelo"))
        right.addWidget(self.ed_nome)
        right.addWidget(QLabel("Meta JSON (campos dinâmicos)"))
        right.addWidget(self.ed_meta, 1)
        right.addWidget(QLabel("HTML (Jinja2)"))
        right.addWidget(self.tx_html, 3)
        self.btn_save = QPushButton("Salvar")
        self.btn_load_file = QPushButton("Carregar HTML de arquivo (assets/templates)")
        rr = QHBoxLayout()
        rr.addWidget(self.btn_save); rr.addWidget(self.btn_load_file)
        right.addLayout(rr)

        root.addLayout(left, 1)
        root.addLayout(right, 2)

        self.btn_new.clicked.connect(self._new)
        self.btn_del.clicked.connect(self._delete)
        self.btn_save.clicked.connect(self._save)
        self.list.currentRowChanged.connect(self._on_select)
        self.btn_load_file.clicked.connect(self._load_from_file)

    def _load(self):
        self.list.clear()
        for m in self.repo.listar_todos():
            self.list.addItem(f"{m['id']} - {m['nome']}")
        if self.list.count() > 0:
            self.list.setCurrentRow(0)

    def _on_select(self, row):
        if row < 0:
            return
        item = self.list.item(row)
        mid = int(item.text().split(' - ')[0])
        self._selected_id = mid
        m = self.repo.get_by_id(mid)
        self.ed_nome.setText(m['nome'])
        self.tx_html.setPlainText(m['html'])
        self.ed_meta.setPlainText(m['meta'] or '{}')

    def _read(self):
        return self.ed_nome.text().strip(), self.tx_html.toPlainText(), self.ed_meta.toPlainText().strip() or '{}'

    def _new(self):
        self._selected_id = None
        self.ed_nome.setText("Novo Modelo")
        self.tx_html.clear()
        self.ed_meta.setPlainText('{}')

    def _save(self):
        nome, html, meta = self._read()
        try:
            json.loads(meta)
        except Exception as e:
            QMessageBox.warning(self, "Meta inválida", f"JSON inválido: {e}")
            return
        if self._selected_id is None:
            self._selected_id = self.repo.add(nome, html, meta)
        else:
            self.repo.update(self._selected_id, nome, html, meta)
        self._load()

    def _delete(self):
        if self._selected_id is None:
            return
        if QMessageBox.question(self, "Confirma", "Excluir o modelo?") == QMessageBox.Yes:
            self.repo.delete(self._selected_id)
            self._selected_id = None
            self._load()

    def _load_from_file(self):
        d = str(ASSETS_DIR / "templates")
        path, _ = QFileDialog.getOpenFileName(self, "Selecione HTML", d, "HTML (*.html)")
        if not path:
            return
        with open(path, "r", encoding="utf-8") as f:
            self.tx_html.setPlainText(f.read())
