from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QListWidget, QLineEdit, QPushButton, QMessageBox
from models.repositories import LookupRepo

TIPOS = [('cid','CID'), ('medicamento','Medicamento'), ('procedimento','Procedimento')]

class CatalogsPage(QWidget):
    def __init__(self, lookup_repo: LookupRepo, parent=None):
        super().__init__(parent)
        self.repo = lookup_repo
        self._build_ui()
        self._load()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        self.cb_tipo = QComboBox()
        for k, label in TIPOS:
            self.cb_tipo.addItem(label, k)
        self.ed_codigo = QLineEdit(); self.ed_codigo.setPlaceholderText("Código (opcional)")
        self.ed_desc = QLineEdit(); self.ed_desc.setPlaceholderText("Descrição")
        self.btn_add = QPushButton("Adicionar")
        top.addWidget(self.cb_tipo); top.addWidget(self.ed_codigo); top.addWidget(self.ed_desc); top.addWidget(self.btn_add)
        lay.addLayout(top)

        self.list = QListWidget()
        lay.addWidget(self.list, 1)

        self.btn_del = QPushButton("Excluir Selecionado")
        lay.addWidget(self.btn_del)

        self.btn_add.clicked.connect(self._add)
        self.btn_del.clicked.connect(self._del)
        self.cb_tipo.currentIndexChanged.connect(self._load)

    def _load(self):
        self.list.clear()
        tipo = self.cb_tipo.currentData()
        for it in self.repo.listar_por_tipo(tipo):
            code = (it['codigo'] + ' - ') if it['codigo'] else ''
            self.list.addItem(f"{it['id']} | {code}{it['descricao']}")

    def _add(self):
        tipo = self.cb_tipo.currentData()
        codigo = self.ed_codigo.text().strip()
        desc = self.ed_desc.text().strip()
        if not desc:
            QMessageBox.warning(self, 'Atenção', 'Descrição obrigatória.')
            return
        self.repo.add(tipo, codigo, desc)
        self.ed_codigo.clear(); self.ed_desc.clear()
        self._load()

    def _del(self):
        item = self.list.currentItem()
        if not item:
            return
        lid = int(item.text().split(' | ')[0])
        self.repo.delete(lid)
        self._load()
