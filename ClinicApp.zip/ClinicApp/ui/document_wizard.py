import json
from datetime import date
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QListWidget, QPushButton, QStackedWidget, QWidget, QFormLayout,
    QComboBox, QLineEdit, QTextEdit, QMessageBox, QListWidgetItem, QLabel, QHBoxLayout, QListWidget
)

from services.template_engine import render_template
from services.pdf_service import html_to_pdf
from models.repositories import ModeloRepo, LookupRepo, ClinicaRepo, PacienteRepo, DocumentoRepo
from config import DOCS_DIR

# ------------------------ Editor de Itens (lookup + valor) ------------------------
class ItemsEditor(QWidget):
    """
    Editor para campos do tipo 'lookup_items':
    - Seleciona itens de um catálogo (lookup_type)
    - Atribui valor a cada item
    - Mantém lista e total
    Retorna lista de dicts: [{codigo, procedimento, valor}, ...]
    """
    def __init__(self, lookup_repo: LookupRepo, lookup_type: str, parent=None):
        super().__init__(parent)
        self.lookup_repo = lookup_repo
        self.lookup_type = lookup_type

        root = QVBoxLayout(self)

        top = QHBoxLayout()
        self.cb = QComboBox()
        self.ed_valor = QLineEdit()
        self.ed_valor.setPlaceholderText("Valor (ex.: 150.00)")
        self.btn_add = QPushButton("Adicionar")

        top.addWidget(self.cb, 3)
        top.addWidget(self.ed_valor, 1)
        top.addWidget(self.btn_add)
        root.addLayout(top)

        self.list = QListWidget()
        root.addWidget(self.list, 1)

        bottom = QHBoxLayout()
        self.btn_del = QPushButton("Remover")
        bottom.addWidget(self.btn_del)
        bottom.addStretch()
        bottom.addWidget(QLabel("Total (R$):"))
        self.lb_total = QLabel("0.00")
        f = self.lb_total.font(); f.setBold(True); self.lb_total.setFont(f)
        bottom.addWidget(self.lb_total)
        root.addLayout(bottom)

        self._load_lookup()
        self.btn_add.clicked.connect(self._add)
        self.btn_del.clicked.connect(self._del)

    def _load_lookup(self):
        self.cb.clear()
        rows = self.lookup_repo.listar_por_tipo(self.lookup_type)
        if not rows:
            self.cb.addItem(f'Cadastre itens ({self.lookup_type}) em Catálogos', None)
            self.btn_add.setEnabled(False)
            return
        for row in rows:
            lbl = f"{row.get('codigo','')} - {row.get('descricao','')}".strip(" -")
            self.cb.addItem(lbl, row)
        self.btn_add.setEnabled(True)

    def _add(self):
        data = self.cb.currentData()
        if not isinstance(data, dict):
            QMessageBox.information(self, "Catálogo vazio", "Cadastre itens no catálogo antes de adicionar.")
            return
        valor_text = (self.ed_valor.text().strip() or "0").replace(",", ".")
        try:
            v = float(valor_text)
        except:
            QMessageBox.warning(self, "Valor inválido", "Informe um valor numérico (ex.: 150.00).")
            return
        label = f"{data.get('codigo','')}|{data.get('descricao','')}|{v:.2f}"
        self.list.addItem(QListWidgetItem(label))
        self.ed_valor.clear()
        self._recalc()

    def _del(self):
        r = self.list.currentRow()
        if r >= 0:
            self.list.takeItem(r)
            self._recalc()

    def _recalc(self):
        total = 0.0
        for i in range(self.list.count()):
            parts = self.list.item(i).text().split("|")
            if len(parts) == 3:
                try:
                    total += float(parts[2])
                except:
                    pass
        self.lb_total.setText(f"{total:.2f}")

    def items(self):
        out = []
        for i in range(self.list.count()):
            code, desc, val = self.list.item(i).text().split("|")
            out.append({"codigo": code, "procedimento": desc, "valor": float(val)})
        return out

    def total(self):
        try:
            return float(self.lb_total.text())
        except:
            return 0.0


# ------------------------------ Assistente de Documentos ------------------------------
class DocumentWizard(QDialog):
    def __init__(self, paciente_id: int, modelo_repo: ModeloRepo, lookup_repo: LookupRepo, clinica_repo: ClinicaRepo, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Assistente de Documentos")
        self.resize(950, 650)
        self.paciente_id = paciente_id
        self.modelos = modelo_repo
        self.lookups = lookup_repo
        self.clinica = clinica_repo
        self.drepo = DocumentoRepo()
        self.prepo = PacienteRepo()
        self._ctx = {}
        self.param_widgets = {}
        self._fields_meta = {}
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        self.stack = QStackedWidget(); root.addWidget(self.stack, 1)

        # Passo 1: escolher modelo
        self.page1 = QWidget(); l1 = QVBoxLayout(self.page1)
        self.list = QListWidget(); l1.addWidget(self.list, 1)
        self.btn1 = QPushButton("Próximo"); l1.addWidget(self.btn1)
        self.stack.addWidget(self.page1)

        # Passo 2: parâmetros (dinâmico)
        self.page2 = QWidget(); l2 = QVBoxLayout(self.page2)
        self.form = QFormLayout()
        container = QWidget(); container.setLayout(self.form)
        l2.addWidget(container, 1)
        self.btn2 = QPushButton("Pré-visualizar"); l2.addWidget(self.btn2)
        self.stack.addWidget(self.page2)

        # Passo 3: prévia → PDF
        self.page3 = QWidget(); l3 = QVBoxLayout(self.page3)
        self.preview = QTextEdit(); self.preview.setReadOnly(True); l3.addWidget(self.preview, 1)
        self.btn3 = QPushButton("Gerar PDF"); l3.addWidget(self.btn3)
        self.stack.addWidget(self.page3)

        self.btn1.clicked.connect(self._to_params)
        self.btn2.clicked.connect(self._to_preview)
        self.btn3.clicked.connect(self._to_pdf)

        self._load_models()

    # ---------- modelos ----------
    def _load_models(self):
        self.list.clear()
        models = self.modelos.listar_todos()
        # Coloca (LEGADO) no fim e destaca os novos
        def sort_key(m):
            name = m["nome"]
            legacy = "(LEGADO" in name or "LEGADO)" in name or "LEGADO" in name
            return (legacy, name.lower())
        models = sorted(models, key=sort_key)
        for m in models:
            self.list.addItem(f"{m['id']} - {m['nome']}")
        if self.list.count() > 0:
            self.list.setCurrentRow(0)

    def _current_model(self):
        item = self.list.currentItem()
        if not item: return None
        mid = int(item.text().split(' - ')[0])
        return self.modelos.get_by_id(mid)

    # ---------- PASSO 2 ----------
    def _to_params(self):
        m = self._current_model()
        if not m: return
        meta = json.loads(m['meta'] or '{}')

        # limpa
        for i in reversed(range(self.form.rowCount())):
            self.form.removeRow(i)
        self.param_widgets = {}
        self._fields_meta = {}

        # cria widgets por campo
        for field in meta.get('fields', []):
            name = field['name']
            label = field.get('label', name)
            ftype = field.get('type', 'text')
            self._fields_meta[name] = field  # guarda configurações

            if ftype == 'lookup':
                cb = QComboBox()
                for row in self.lookups.listar_por_tipo(field['lookup_type']):
                    lbl = f"{row['codigo']} - {row['descricao']}" if row['codigo'] else row['descricao']
                    cb.addItem(lbl, row)
                self.param_widgets[name] = cb
                self.form.addRow(label, cb)

            elif ftype == 'lookup_multi':
                lst = QListWidget()
                lst.setSelectionMode(QListWidget.MultiSelection)
                for row in self.lookups.listar_por_tipo(field['lookup_type']):
                    lbl = f"{row['codigo']} - {row['descricao']}" if row['codigo'] else row['descricao']
                    it = QListWidgetItem(lbl)
                    it.setData(Qt.UserRole, row)
                    lst.addItem(it)
                self.param_widgets[name] = lst
                self.form.addRow(label, lst)

            elif ftype == 'lookup_items':
                editor = ItemsEditor(self.lookups, field['lookup_type'])
                self.param_widgets[name] = editor
                self.form.addRow(label, editor)

            elif ftype == 'choice':
                cb = QComboBox()
                for opt in field.get('options', []):
                    cb.addItem(opt, opt)
                self.param_widgets[name] = cb
                self.form.addRow(label, cb)

            elif ftype == 'longtext':
                tx = QTextEdit()
                self.param_widgets[name] = tx
                self.form.addRow(label, tx)

            elif ftype == 'date':
                ed = QLineEdit(date.today().strftime('%d/%m/%Y'))
                self.param_widgets[name] = ed
                self.form.addRow(label, ed)

            else:  # text/int etc.
                ed = QLineEdit()
                self.param_widgets[name] = ed
                self.form.addRow(label, ed)

        self.stack.setCurrentWidget(self.page2)

    def _collect_params(self):
        params = {}
        for name, w in self.param_widgets.items():
            meta = self._fields_meta.get(name, {})
            ftype = meta.get('type')

            if ftype == 'lookup':
                data = w.currentData() if isinstance(w, QComboBox) else None
                if isinstance(data, dict):
                    params[name] = data.get('descricao', '')
                    params[name + '_codigo'] = data.get('codigo', '')
                else:
                    params[name] = w.currentText() if isinstance(w, QComboBox) else ''
                continue

            if ftype == 'lookup_multi':
                descrs, cods = [], []
                if isinstance(w, QListWidget):
                    for i in range(w.count()):
                        it = w.item(i)
                        if it.isSelected():
                            row = it.data(Qt.UserRole) or {}
                            descrs.append(row.get('descricao',''))
                            cods.append(row.get('codigo',''))
                params[name] = descrs
                params[name + "_codigos"] = cods
                continue

            if ftype == 'lookup_items':
                # lista com valores + total
                items = w.items()
                params[name] = items
                total_field = meta.get('total_field')
                if total_field:
                    params[total_field] = f"{sum(i['valor'] for i in items):.2f}"
                continue

            if ftype == 'choice':
                params[name] = w.currentText() if isinstance(w, QComboBox) else ''
                continue

            if ftype == 'longtext' and hasattr(w, 'toPlainText'):
                params[name] = w.toPlainText().strip()
                continue

            if hasattr(w, 'text'):
                params[name] = w.text().strip()

        return params

    # ---------- PASSO 3 ----------
    def _to_preview(self):
        m = self._current_model()
        if not m: return
        p = self.prepo.get_by_id(self.paciente_id) or {}

        # anexar anamnese estruturada ao dicionário do paciente
        try:
            an = json.loads(p.get('anamnese_json') or '{}')
        except Exception:
            an = {}
        p['anamnese'] = an

        params = self._collect_params()
        self._ctx = {
            'paciente': p,
            'clinica': self.clinica.get(),
            'extras': params,
            'hoje': date.today().strftime('%d/%m/%Y')
        }
        html = render_template(m['html'], self._ctx)
        self.preview.setHtml(html)
        self.stack.setCurrentWidget(self.page3)

    def _to_pdf(self):
        m = self._current_model()
        if not m: return
        html = render_template(m['html'], self._ctx)
        out = Path(DOCS_DIR) / f"documento_{m['nome'].replace(' ', '_')}_{date.today().isoformat()}.pdf"
        html_to_pdf(html, out)
        self.drepo.add(
            paciente_id=self.paciente_id,
            modelo_id=m['id'],
            parametros=self._ctx.get('extras', {}),
            caminho_pdf=str(out),
            data_criacao=date.today().isoformat()
        )
        QMessageBox.information(self, "Sucesso", f"PDF gerado em:\n{out}")
        self.accept()
