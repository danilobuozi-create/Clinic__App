from datetime import date
from PySide6.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout, QFormLayout, QComboBox, QLineEdit, QTextEdit, QPushButton, QMessageBox
from models.repositories import PacienteRepo, LookupRepo, ClinicaRepo, ModeloRepo, DocumentoRepo
from services.template_engine import render_template
from services.pdf_service import html_to_pdf
from config import DOCS_DIR, ASSETS_DIR
from pathlib import Path

class CertificatePage(QWidget):
    def __init__(self, paciente_repo: PacienteRepo, lookup_repo: LookupRepo, clinica_repo: ClinicaRepo, parent=None):
        super().__init__(parent)
        self.pacientes = paciente_repo
        self.lookups = lookup_repo
        self.clinica = clinica_repo
        self._build()

    def _build(self):
        root = QHBoxLayout(self)

        left = QVBoxLayout()
        self.cb_paciente = QComboBox(); self._load_pacientes()
        left.addWidget(self.cb_paciente)

        self.cb_cid = QComboBox(); self._load_cids()
        left.addWidget(self.cb_cid)

        form = QFormLayout()
        self.ed_data = QLineEdit(date.today().strftime('%d/%m/%Y')); form.addRow('Data', self.ed_data)
        self.ed_repouso = QLineEdit('1'); form.addRow('Repouso (dias)', self.ed_repouso)
        left.addLayout(form)

        self.btn_pdf = QPushButton('Imprimir Documento (Gerar PDF)')
        left.addWidget(self.btn_pdf)

        right = QVBoxLayout()
        self.tx_preview = QTextEdit(); self.tx_preview.setReadOnly(True)
        right.addWidget(self.tx_preview, 1)

        root.addLayout(left, 2)
        root.addLayout(right, 3)

        self.cb_paciente.currentIndexChanged.connect(self._preview)
        self.cb_cid.currentIndexChanged.connect(self._preview)
        self.ed_data.textChanged.connect(self._preview)
        self.ed_repouso.textChanged.connect(self._preview)
        self.btn_pdf.clicked.connect(self._generate)

        self._preview()

    def _load_pacientes(self):
        self.cb_paciente.clear()
        for p in self.pacientes.listar_todos():
            self.cb_paciente.addItem(p['nome'], p)

    def _load_cids(self):
        self.cb_cid.clear()
        for c in self.lookups.listar_por_tipo('cid'):
            label = f"{c['codigo']} - {c['descricao']}" if c['codigo'] else c['descricao']
            self.cb_cid.addItem(label, c)

    def _preview(self):
        p = self.cb_paciente.currentData() or {}
        c = self.cb_cid.currentData() or {'codigo':'','descricao':''}
        ctx = {
            'paciente': p, 'clinica': self.clinica.get(),
            'extras': {'cid_codigo': c.get('codigo',''), 'cid_descricao': c.get('descricao',''),
                       'repouso_dias': self.ed_repouso.text().strip(), 'data': self.ed_data.text().strip()},
            'hoje': date.today().strftime('%d/%m/%Y')
        }
        html = "<h3>Prévia do Atestado</h3><p>Paciente: {{ paciente.nome }}<br>CID: {{ extras.cid_codigo }} - {{ extras.cid_descricao }}<br>Repouso: {{ extras.repouso_dias }} dia(s)</p>"
        self.tx_preview.setHtml(render_template(html, ctx))

    def _generate(self):
        if self.cb_paciente.currentIndex() < 0:
            QMessageBox.warning(self, 'Atenção', 'Selecione um paciente.')
            return
        mrepo, drepo = ModeloRepo(), DocumentoRepo()
        model = mrepo.find_by_name("Atestado")
        if model:
            tpl = model['html']; mid = model['id']
        else:
            with open(ASSETS_DIR / 'templates' / 'atestado.html', 'r', encoding='utf-8') as f:
                tpl = f.read()
            mid = None
        p = self.cb_paciente.currentData()
        c = self.cb_cid.currentData() or {'codigo':'','descricao':''}
        ctx = {
            'paciente': p, 'clinica': self.clinica.get(),
            'extras': {'cid_codigo': c.get('codigo',''), 'cid_descricao': c.get('descricao',''),
                       'repouso_dias': self.ed_repouso.text().strip(), 'data': self.ed_data.text().strip()},
            'hoje': date.today().strftime('%d/%m/%Y')
        }
        html = render_template(tpl, ctx)
        out = Path(DOCS_DIR) / f"atestado_{p['nome'].replace(' ','_')}_{date.today().isoformat()}.pdf"
        html_to_pdf(html, out)
        drepo.add(paciente_id=p['id'], modelo_id=mid, parametros=ctx['extras'], caminho_pdf=str(out), data_criacao=date.today().isoformat())
        QMessageBox.information(self, 'Sucesso', f'PDF gerado em:\n{out}')
