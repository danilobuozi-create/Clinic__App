from PySide6.QtWidgets import QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QHBoxLayout, QMessageBox
from PySide6.QtGui import QDesktopServices
from PySide6.QtCore import QUrl
from models.repositories import DocumentoRepo

class DocumentsPage(QWidget):
    def __init__(self, documento_repo: DocumentoRepo, parent=None):
        super().__init__(parent)
        self.repo = documento_repo
        self._build_ui()
        self._load()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(['ID', 'Data', 'Paciente', 'Modelo', 'PDF'])
        lay.addWidget(self.table)

        row = QHBoxLayout()
        self.btn_refresh = QPushButton('Atualizar')
        self.btn_open = QPushButton('Abrir Selecionado')
        row.addWidget(self.btn_refresh)
        row.addWidget(self.btn_open)
        row.addStretch()
        lay.addLayout(row)

        self.btn_refresh.clicked.connect(self._load)
        self.btn_open.clicked.connect(self._open_selected)

    def _load(self):
        docs = self.repo.listar_todos()
        self.table.setRowCount(len(docs))
        for r, d in enumerate(docs):
            self.table.setItem(r, 0, QTableWidgetItem(str(d['id'])))
            self.table.setItem(r, 1, QTableWidgetItem(str(d['data_criacao'])))
            self.table.setItem(r, 2, QTableWidgetItem(d.get('paciente_nome') or ''))
            self.table.setItem(r, 3, QTableWidgetItem(d.get('modelo_nome') or ''))
            self.table.setItem(r, 4, QTableWidgetItem(d.get('caminho_pdf') or ''))
        self.table.resizeColumnsToContents()

    def _open_selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Abrir PDF", "Selecione um documento na tabela.")
            return
        path = self.table.item(row, 4).text()
        if not path:
            QMessageBox.warning(self, "Abrir PDF", "Caminho do PDF vazio.")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))
