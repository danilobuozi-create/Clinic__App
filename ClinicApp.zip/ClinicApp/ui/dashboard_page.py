from PySide6.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout, QLabel, QListWidget, QGroupBox
from models.repositories import PacienteRepo, ClinicaRepo

class DashboardPage(QWidget):
    def __init__(self, paciente_repo: PacienteRepo, clinica_repo: ClinicaRepo, parent=None):
        super().__init__(parent)
        self.pacientes = paciente_repo
        self.clinica = clinica_repo
        self._build()

    def _build(self):
        root = QHBoxLayout(self)

        left_group = QGroupBox('Lista de Pacientes')
        l = QVBoxLayout(left_group)
        self.list = QListWidget()
        l.addWidget(self.list)
        root.addWidget(left_group, 2)

        right = QVBoxLayout()
        clinic_group = QGroupBox('Dados da Clínica (informativo)')
        cl = QVBoxLayout(clinic_group)
        self.lb_data = QLabel('')
        self.lb_data.setWordWrap(True)
        cl.addWidget(self.lb_data)

        resp_group = QGroupBox('Área do Responsável')
        rl = QVBoxLayout(resp_group)
        rl.addWidget(QLabel('Relatórios agregados podem ser exibidos aqui.'))

        right.addWidget(clinic_group, 2)
        right.addWidget(resp_group, 1)

        root.addLayout(right, 3)
        self._refresh()

    def _refresh(self):
        self.list.clear()
        for p in self.pacientes.listar_todos():
            self.list.addItem(f"{p['id']} - {p['nome']}")
        c = self.clinica.get()
        txt = (
            f"<b>{c.get('nome','')}</b><br>"
            f"CNPJ: {c.get('cnpj','')} · EPAO: {c.get('epao','')}<br>"
            f"Responsável: {c.get('responsavel_tecnico','')} (CRO {c.get('cro','')})<br>"
            f"{c.get('endereco','')} - {c.get('cidade','')}/{c.get('uf','')}<br>"
            f"Tel: {c.get('telefone','')} · Email: {c.get('email','')}"
        )
        self.lb_data.setText(txt)
