from PySide6.QtWidgets import QMainWindow, QTabWidget
from .patients_page import PatientsPage
from .templates_page import TemplatesPage
from .documents_page import DocumentsPage
from .prescription_page import PrescriptionPage
from .certificate_page import CertificatePage
from .catalogs_page import CatalogsPage
from .settings_page import SettingsPage
from .dashboard_page import DashboardPage
from .plan_page import PlanPage
from models.repositories import PacienteRepo, ModeloRepo, DocumentoRepo, LookupRepo, ClinicaRepo

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ClinicApp - Sistema Offline para Clínica Odontológica")
        self.resize(1200, 800)

        self.pacientes = PacienteRepo()
        self.modelos = ModeloRepo()
        self.documentos = DocumentoRepo()
        self.lookups = LookupRepo()
        self.clinica = ClinicaRepo()

        tabs = QTabWidget(self)
        tabs.setMovable(True)
        self.setCentralWidget(tabs)

        tabs.addTab(DashboardPage(self.pacientes, self.clinica), "Dashboard")
        tabs.addTab(PatientsPage(self.pacientes, self.modelos, self.lookups, self.clinica), "Pacientes")
        tabs.addTab(PrescriptionPage(self.pacientes, self.lookups, self.clinica), "Prescrição de Medicamentos")
        tabs.addTab(CertificatePage(self.pacientes, self.lookups, self.clinica), "Atestado Odontológico")
        tabs.addTab(PlanPage(self.pacientes, self.lookups, self.clinica), "Orçamento/Plano")
        tabs.addTab(DocumentsPage(self.documentos), "Documentos")
        tabs.addTab(TemplatesPage(self.modelos), "Modelos (Templates)")
        tabs.addTab(CatalogsPage(self.lookups), "Catálogos")
        tabs.addTab(SettingsPage(self.clinica), "Configurações")
