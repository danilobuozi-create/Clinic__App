from datetime import date
from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QFormLayout, QComboBox, QLineEdit,
    QTextEdit, QPushButton, QListWidget, QMessageBox, QLabel
)
from models.repositories import PacienteRepo, LookupRepo, ClinicaRepo, ModeloRepo, DocumentoRepo
from services.template_engine import render_template
from services.pdf_service import html_to_pdf
from config import DOCS_DIR, ASSETS_DIR
from pathlib import Path

class PrescriptionPage(QWidget):
    def __init__(self, paciente_repo: PacienteRepo, lookup_repo: LookupRepo, clinica_repo: ClinicaRepo, parent=None):
        super().__init__(parent)
        self.pacientes = paciente_repo
        self.lookups = lookup_repo
        self.clinica = clinica_repo
        self._build()

    def _build(self):
        root = QHBoxLayout(self)

        # Esquerda
        left = QVBoxLayout()
        self.cb_paciente = QComboBox(); self._load_pacientes(); left.addWidget(self.cb_paciente)
        self.cb_meds = QComboBox(); self._load_meds(); left.addWidget(self.cb_meds)
        self.list_itens = QListWidget(); left.addWidget(self.list_itens, 1)

        add_line = QFormLayout()
        self.ed_posologia = QLineEdit(); add_line.addRow('Posologia', self.ed_posologia)
        self.ed_qtde = QLineEdit(); add_line.addRow('Quantidade', self.ed_qtde)
        left.addLayout(add_line)

        btns = QHBoxLayout()
        self.btn_add = QPushButton('Adicionar Item'); btns.addWidget(self.btn_add)
        self.btn_del = QPushButton('Remover Selecionado'); btns.addWidget(self.btn_del)
        left.addLayout(btns)

        # Direita
        right = QVBoxLayout()
        self.tx_preview = QTextEdit(); self.tx_preview.setReadOnly(True)
        right.addWidget(self.tx_preview, 1)
        self.ed_obs = QLineEdit(); self.ed_obs.setPlaceholderText('Observações')
        right.addWidget(self.ed_obs)
        self.btn_render = QPushButton('Gerar PDF')
        right.addWidget(self.btn_render)

        root.addLayout(left, 2)
        root.addLayout(right, 3)

        # sinais
        self.btn_add.clicked.connect(self._add_item)
        self.btn_del.clicked.connect(self._del_item)
        self.btn_render.clicked.connect(self._generate)
        self.ed_obs.textChanged.connect(self._preview)
        self.cb_paciente.currentIndexChanged.connect(self._on_any_change)
        self.cb_meds.currentIndexChanged.connect(self._on_any_change)
        self.list_itens.itemChanged.connect(self._on_any_change)  # caso edite no futuro
        self.list_itens.itemSelectionChanged.connect(self._on_any_change)

        self._on_any_change()
        self._preview()

    # ---------------- helpers ----------------

    def _load_pacientes(self):
        self.cb_paciente.clear()
        rows = self.pacientes.listar_todos()
        if not rows:
            self.cb_paciente.addItem('Cadastre pacientes na aba "Pacientes"', None)
            return
        for p in rows:
            self.cb_paciente.addItem(p['nome'], p)

    def _load_meds(self):
        self.cb_meds.clear()
        meds = self.lookups.listar_por_tipo('medicamento')
        if not meds:
            # placeholder amigável
            self.cb_meds.addItem('Cadastre medicamentos em "Catálogos → Medicamento"', None)
            return
        for m in meds:
            label = (m['codigo'] + ' - ') if m['codigo'] else ''
            label += m['descricao']
            self.cb_meds.addItem(label, m)

    def _collect_items(self):
        itens = []
        for i in range(self.list_itens.count()):
            txt = self.list_itens.item(i).text()
            parts = [p.strip() for p in txt.split('|')]
            itens.append({
                'medicamento': parts[0] if len(parts) > 0 else '',
                'posologia'  : parts[1] if len(parts) > 1 else '',
                'quantidade' : parts[2] if len(parts) > 2 else '1'
            })
        return itens

    def _preview(self):
        paciente = self.cb_paciente.currentData()
        clinica = self.clinica.get()
        ctx = {
            'paciente': paciente or {},
            'clinica': clinica or {},
            'extras': {'itens': self._collect_items(), 'observacoes': self.ed_obs.text().strip()},
            'hoje': date.today().strftime('%d/%m/%Y')
        }
        html = "<h3>Prévia do Receituário</h3><p>Paciente: {{ paciente.nome or '' }}</p><ul>{% for i in extras.itens %}<li>{{ i.medicamento }} - {{ i.posologia }} ({{ i.quantidade }})</li>{% endfor %}</ul><p>{{ extras.observacoes }}</p>"
        self.tx_preview.setHtml(render_template(html, ctx))

    def _enable_states(self):
        # habilita/desabilita botões conforme disponibilidade de dados
        has_paciente = isinstance(self.cb_paciente.currentData(), dict)
        med_data = self.cb_meds.currentData()
        has_meds = isinstance(med_data, dict)
        has_itens = self.list_itens.count() > 0

        self.btn_add.setEnabled(has_meds)           # só adiciona se houver medicamento real
        self.btn_render.setEnabled(has_paciente and has_itens)

    # ---------------- slots ----------------

    def _on_any_change(self):
        self._enable_states()
        self._preview()

    def _add_item(self):
        med = self.cb_meds.currentData()
        if not isinstance(med, dict):
            QMessageBox.information(self, 'Medicamentos',
                                    'Cadastre medicamentos em "Catálogos → Medicamento" antes de adicionar.')
            return
        pos = self.ed_posologia.text().strip()
        qt = self.ed_qtde.text().strip() or '1'
        label = f"{med.get('descricao','')} | {pos} | {qt}"
        self.list_itens.addItem(label)
        self.ed_posologia.clear(); self.ed_qtde.clear()
        self._on_any_change()

    def _del_item(self):
        idx = self.list_itens.currentRow()
        if idx >= 0:
            self.list_itens.takeItem(idx)
        self._on_any_change()

    def _generate(self):
        paciente = self.cb_paciente.currentData()
        if not isinstance(paciente, dict):
            QMessageBox.warning(self, 'Atenção', 'Selecione um paciente válido.')
            return
        if self.list_itens.count() == 0:
            QMessageBox.warning(self, 'Atenção', 'Adicione ao menos um item.')
            return

        mrepo, drepo = ModeloRepo(), DocumentoRepo()
        model = mrepo.find_by_name("Receituário")
        if model:
            tpl = model['html']; mid = model['id']
        else:
            with open(ASSETS_DIR / 'templates' / 'receita.html', 'r', encoding='utf-8') as f:
                tpl = f.read()
            mid = None

        clinica = self.clinica.get()
        ctx = {
            'paciente': paciente or {},
            'clinica': clinica or {},
            'extras': {'itens': self._collect_items(), 'observacoes': self.ed_obs.text().strip()},
            'hoje': date.today().strftime('%d/%m/%Y')
        }
        html = render_template(tpl, ctx)
        out = Path(DOCS_DIR) / f"receita_{paciente['nome'].replace(' ', '_')}_{date.today().isoformat()}.pdf"
        html_to_pdf(html, out)
        drepo.add(paciente_id=paciente['id'], modelo_id=mid, parametros=ctx['extras'], caminho_pdf=str(out), data_criacao=date.today().isoformat())
        QMessageBox.information(self, 'Sucesso', f'PDF gerado em:\n{out}')
