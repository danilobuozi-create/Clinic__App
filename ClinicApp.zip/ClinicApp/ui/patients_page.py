import json
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QListWidget, QFormLayout,
    QLineEdit, QTextEdit, QMessageBox, QWidget, QGroupBox, QComboBox, QSpinBox, QLabel, QGridLayout, QCheckBox
)
from PySide6.QtCore import Qt
from .document_wizard import DocumentWizard

# --------- Widget de Anamnese Estruturada (CRO-SP) ----------
class AnamneseWidget(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Anamnese (CRO-SP)", parent)
        self._build()

    def _build(self):
        g = QGridLayout(self)

        row = 0
        # 1) Tomando medicamento?
        self.cb_tomando_meds = QComboBox(); self.cb_tomando_meds.addItems(["Não","Sim"])
        self.ed_quais_meds = QLineEdit()
        g.addWidget(QLabel("Está tomando algum medicamento?"), row, 0)
        g.addWidget(self.cb_tomando_meds, row, 1)
        g.addWidget(QLabel("Quais?"), row, 2)
        g.addWidget(self.ed_quais_meds, row, 3); row += 1

        # 2) Alergia
        self.cb_alergia = QComboBox(); self.cb_alergia.addItems(["Não","Sim","Não sei"])
        self.ed_qual_alergia = QLineEdit()
        g.addWidget(QLabel("Tem algum tipo de alergia?"), row, 0)
        g.addWidget(self.cb_alergia, row, 1)
        g.addWidget(QLabel("Qual?"), row, 2)
        g.addWidget(self.ed_qual_alergia, row, 3); row += 1

        # 3) Pressão
        self.cb_pressao = QComboBox(); self.cb_pressao.addItems(["Normal","Alta","Baixa","Controlada com medicamento"])
        g.addWidget(QLabel("Sua pressão é:"), row, 0)
        g.addWidget(self.cb_pressao, row, 1); row += 1

        # 4) Coração
        self.cb_coracao = QComboBox(); self.cb_coracao.addItems(["Não","Sim"])
        self.ed_coracao_qual = QLineEdit()
        g.addWidget(QLabel("Tem/teve problema de coração?"), row, 0)
        g.addWidget(self.cb_coracao, row, 1)
        g.addWidget(QLabel("Qual?"), row, 2)
        g.addWidget(self.ed_coracao_qual, row, 3); row += 1

        # 5) Falta de ar
        self.cb_falta_ar = QComboBox(); self.cb_falta_ar.addItems(["Não","Sim"])
        g.addWidget(QLabel("Sente falta de ar com frequência?"), row, 0)
        g.addWidget(self.cb_falta_ar, row, 1); row += 1

        # 6) Diabetes
        self.cb_diabetes = QComboBox(); self.cb_diabetes.addItems(["Não","Sim","Não sei"])
        g.addWidget(QLabel("Tem diabetes?"), row, 0)
        g.addWidget(self.cb_diabetes, row, 1); row += 1

        # 7) Sangramento
        self.cb_sangramento = QComboBox(); self.cb_sangramento.addItems(["Normal","Excessivo"])
        g.addWidget(QLabel("Quando se corta há um sangramento:"), row, 0)
        g.addWidget(self.cb_sangramento, row, 1); row += 1

        # 8) Cicatrização
        self.cb_cicatrizacao = QComboBox(); self.cb_cicatrizacao.addItems(["Normal","Complicada"])
        g.addWidget(QLabel("Sua cicatrização é:"), row, 0)
        g.addWidget(self.cb_cicatrizacao, row, 1); row += 1

        # 9) Cirurgia
        self.cb_cirurgia = QComboBox(); self.cb_cirurgia.addItems(["Não","Sim"])
        g.addWidget(QLabel("Já fez alguma cirurgia?"), row, 0)
        g.addWidget(self.cb_cirurgia, row, 1); row += 1

        # 10) Gestante
        self.cb_gestante = QComboBox(); self.cb_gestante.addItems(["Não","Sim","Não sei"])
        self.ed_gestante_semanas = QLineEdit()
        g.addWidget(QLabel("Gestante?"), row, 0)
        g.addWidget(self.cb_gestante, row, 1)
        g.addWidget(QLabel("Semanas:"), row, 2)
        g.addWidget(self.ed_gestante_semanas, row, 3); row += 1

        # 11) Problemas de saúde que já teve
        self.ed_prob_saude = QLineEdit()
        g.addWidget(QLabel("Problemas de saúde que já teve:"), row, 0)
        g.addWidget(self.ed_prob_saude, row, 1, 1, 3); row += 1

        # 12) Queixa principal
        self.ed_queixa = QLineEdit()
        g.addWidget(QLabel("Queixa principal:"), row, 0)
        g.addWidget(self.ed_queixa, row, 1, 1, 3); row += 1

        # 13) Reação com anestesia
        self.cb_reacao_anest = QComboBox(); self.cb_reacao_anest.addItems(["Não","Sim"])
        self.ed_reacao_quais = QLineEdit()
        g.addWidget(QLabel("Já teve reação com anestesia dental?"), row, 0)
        g.addWidget(self.cb_reacao_anest, row, 1)
        g.addWidget(QLabel("Qual?"), row, 2)
        g.addWidget(self.ed_reacao_quais, row, 3); row += 1

        # 14) Último tratamento
        self.ed_ultimo_trat = QLineEdit()
        g.addWidget(QLabel("Quando foi seu último tratamento dentário?"), row, 0)
        g.addWidget(self.ed_ultimo_trat, row, 1, 1, 3); row += 1

        # 15) Dor dentes/gengiva
        self.cb_dor = QComboBox(); self.cb_dor.addItems(["Não","Sim"])
        g.addWidget(QLabel("Tem sentido dor nos dentes ou na gengiva?"), row, 0)
        g.addWidget(self.cb_dor, row, 1); row += 1

        # 16) Gengiva sangra
        self.cb_gengiva_sangra = QComboBox(); self.cb_gengiva_sangra.addItems(["Não","Sim","Durante a higiene","Às vezes"])
        g.addWidget(QLabel("Sua gengiva sangra?"), row, 0)
        g.addWidget(self.cb_gengiva_sangra, row, 1); row += 1

        # 17) Gosto ruim / boca seca
        self.cb_boca_seca = QComboBox(); self.cb_boca_seca.addItems(["Não","Sim"])
        g.addWidget(QLabel("Tem sentido gosto ruim na boca ou boca seca?"), row, 0)
        g.addWidget(self.cb_boca_seca, row, 1); row += 1

        # 18) Escova quantas vezes
        self.ed_escova_vezes = QLineEdit()
        g.addWidget(QLabel("Quantas vezes escova os dentes por dia?"), row, 0)
        g.addWidget(self.ed_escova_vezes, row, 1, 1, 3); row += 1

        # 19) Fio dental
        self.cb_fio_dental = QComboBox(); self.cb_fio_dental.addItems(["Não","Diariamente","Às vezes"])
        g.addWidget(QLabel("Usa fio dental?"), row, 0)
        g.addWidget(self.cb_fio_dental, row, 1); row += 1

        # 20) Estalos/dor maxilar
        self.cb_estalos = QComboBox(); self.cb_estalos.addItems(["Não","Sim"])
        g.addWidget(QLabel("Sente dores ou estalos no maxilar ou no ouvido?"), row, 0)
        g.addWidget(self.cb_estalos, row, 1); row += 1

        # 21) Range os dentes
        self.cb_bruxismo = QComboBox(); self.cb_bruxismo.addItems(["Não","Sim"])
        g.addWidget(QLabel("Range os dentes (dia/noite)?"), row, 0)
        g.addWidget(self.cb_bruxismo, row, 1); row += 1

        # 22) Feridas/bolhas
        self.cb_feridas = QComboBox(); self.cb_feridas.addItems(["Não","Sim"])
        g.addWidget(QLabel("Já teve ferida/bolha na face ou lábios?"), row, 0)
        g.addWidget(self.cb_feridas, row, 1); row += 1

        # 23) Fuma
        self.cb_fuma = QComboBox(); self.cb_fuma.addItems(["Não","Sim"])
        self.ed_fuma_qtd = QLineEdit()
        g.addWidget(QLabel("Fuma?"), row, 0)
        g.addWidget(self.cb_fuma, row, 1)
        g.addWidget(QLabel("Quantidade:"), row, 2)
        g.addWidget(self.ed_fuma_qtd, row, 3); row += 1

        # Declaração (texto informativo)
        info = QLabel('Declaro, para fins de direito, que as informações acima prestadas são verdadeiras.')
        info.setWordWrap(True)
        g.addWidget(info, row, 0, 1, 4)

    def to_dict(self) -> dict:
        return {
            "tomando_medicamento": self.cb_tomando_meds.currentText(),
            "quais_medicamentos": self.ed_quais_meds.text().strip(),
            "alergia": self.cb_alergia.currentText(),
            "qual_alergia": self.ed_qual_alergia.text().strip(),
            "pressao": self.cb_pressao.currentText(),
            "problema_coracao": self.cb_coracao.currentText(),
            "coracao_qual": self.ed_coracao_qual.text().strip(),
            "falta_ar": self.cb_falta_ar.currentText(),
            "diabetes": self.cb_diabetes.currentText(),
            "sangramento": self.cb_sangramento.currentText(),
            "cicatrizacao": self.cb_cicatrizacao.currentText(),
            "cirurgia": self.cb_cirurgia.currentText(),
            "gestante": self.cb_gestante.currentText(),
            "gestante_semanas": self.ed_gestante_semanas.text().strip(),
            "problemas_saude_passado": self.ed_prob_saude.text().strip(),
            "queixa_principal": self.ed_queixa.text().strip(),
            "reacao_anestesia": self.cb_reacao_anest.currentText(),
            "reacao_anestesia_qual": self.ed_reacao_quais.text().strip(),
            "ultimo_tratamento": self.ed_ultimo_trat.text().strip(),
            "dor_dentes_gengiva": self.cb_dor.currentText(),
            "gengiva_sangra": self.cb_gengiva_sangra.currentText(),
            "boca_seca": self.cb_boca_seca.currentText(),
            "escova_vezes_dia": self.ed_escova_vezes.text().strip(),
            "fio_dental": self.cb_fio_dental.currentText(),
            "estalos_maxilar": self.cb_estalos.currentText(),
            "bruxismo": self.cb_bruxismo.currentText(),
            "feridas_face_labios": self.cb_feridas.currentText(),
            "fuma": self.cb_fuma.currentText(),
            "fuma_quantidade": self.ed_fuma_qtd.text().strip(),
        }

    def from_dict(self, data: dict):
        if not data: return
        def set_combo(cb: QComboBox, val: str):
            if val is None: return
            idx = cb.findText(val)
            if idx >= 0: cb.setCurrentIndex(idx)
        set_combo(self.cb_tomando_meds, data.get("tomando_medicamento"))
        self.ed_quais_meds.setText(data.get("quais_medicamentos",""))
        set_combo(self.cb_alergia, data.get("alergia"))
        self.ed_qual_alergia.setText(data.get("qual_alergia",""))
        set_combo(self.cb_pressao, data.get("pressao"))
        set_combo(self.cb_coracao, data.get("problema_coracao"))
        self.ed_coracao_qual.setText(data.get("coracao_qual",""))
        set_combo(self.cb_falta_ar, data.get("falta_ar"))
        set_combo(self.cb_diabetes, data.get("diabetes"))
        set_combo(self.cb_sangramento, data.get("sangramento"))
        set_combo(self.cb_cicatrizacao, data.get("cicatrizacao"))
        set_combo(self.cb_cirurgia, data.get("cirurgia"))
        set_combo(self.cb_gestante, data.get("gestante"))
        self.ed_gestante_semanas.setText(data.get("gestante_semanas",""))
        self.ed_prob_saude.setText(data.get("problemas_saude_passado",""))
        self.ed_queixa.setText(data.get("queixa_principal",""))
        set_combo(self.cb_reacao_anest, data.get("reacao_anestesia"))
        self.ed_reacao_quais.setText(data.get("reacao_anestesia_qual",""))
        self.ed_ultimo_trat.setText(data.get("ultimo_tratamento",""))
        set_combo(self.cb_dor, data.get("dor_dentes_gengiva"))
        set_combo(self.cb_gengiva_sangra, data.get("gengiva_sangra"))
        set_combo(self.cb_boca_seca, data.get("boca_seca"))
        self.ed_escova_vezes.setText(data.get("escova_vezes_dia",""))
        set_combo(self.cb_fio_dental, data.get("fio_dental"))
        set_combo(self.cb_estalos, data.get("estalos_maxilar"))
        set_combo(self.cb_bruxismo, data.get("bruxismo"))
        set_combo(self.cb_feridas, data.get("feridas_face_labios"))
        set_combo(self.cb_fuma, data.get("fuma"))
        self.ed_fuma_qtd.setText(data.get("fuma_quantidade",""))

class PatientsPage(QWidget):
    def __init__(self, paciente_repo, modelo_repo, lookup_repo, clinica_repo, parent=None):
        super().__init__(parent)
        self.repo = paciente_repo
        self.modelo_repo = modelo_repo
        self.lookup_repo = lookup_repo
        self.clinica_repo = clinica_repo
        self._selected_id = None
        self._build_ui()
        self._load_list()

    def _build_ui(self):
        root = QHBoxLayout(self)

        # Coluna esquerda: lista
        left = QVBoxLayout()
        self.btn_novo = QPushButton("Novo Paciente")
        self.btn_delete = QPushButton("Excluir")
        left.addWidget(self.btn_novo)
        left.addWidget(self.btn_delete)
        self.lista = QListWidget()
        left.addWidget(self.lista, 1)

        # Coluna direita: formulário
        form_widget = QWidget()
        form = QFormLayout(form_widget)
        self.ed_nome = QLineEdit(); form.addRow("Nome*", self.ed_nome)
        self.ed_cpf = QLineEdit(); form.addRow("CPF", self.ed_cpf)
        self.ed_rg = QLineEdit(); form.addRow("RG", self.ed_rg)
        self.ed_sexo = QLineEdit(); form.addRow("Sexo", self.ed_sexo)
        self.ed_nasc = QLineEdit(); form.addRow("Nascimento (YYYY-MM-DD)", self.ed_nasc)
        self.ed_tel = QLineEdit(); form.addRow("Telefone", self.ed_tel)
        self.ed_email = QLineEdit(); form.addRow("Email", self.ed_email)
        self.ed_end = QLineEdit(); form.addRow("Endereço", self.ed_end)
        self.ed_alerg = QLineEdit(); form.addRow("Alergias (observações)", self.ed_alerg)

        # Anamnese estruturada
        self.anamnese = AnamneseWidget()
        form.addRow(self.anamnese)

        # Observações livres
        self.tx_anamnese_livre = QTextEdit(); form.addRow("Anamnese (livre)", self.tx_anamnese_livre)
        self.tx_obs = QTextEdit(); form.addRow("Observações gerais", self.tx_obs)

        bline = QHBoxLayout()
        self.btn_salvar = QPushButton("Salvar")
        self.btn_doc = QPushButton("Gerar Documento (Assistente)")
        bline.addWidget(self.btn_salvar)
        bline.addWidget(self.btn_doc)
        form.addRow(bline)

        root.addLayout(left, 1)
        root.addWidget(form_widget, 2)

        # sinais
        self.btn_novo.clicked.connect(self._new)
        self.btn_salvar.clicked.connect(self._save)
        self.btn_delete.clicked.connect(self._delete)
        self.lista.currentRowChanged.connect(self._on_select)
        self.btn_doc.clicked.connect(self._open_wizard)

    def _load_list(self):
        self.lista.clear()
        for p in self.repo.listar_todos():
            self.lista.addItem(f"{p['id']} - {p['nome']}")
        if self.lista.count() > 0:
            self.lista.setCurrentRow(0)

    def _read_form(self):
        # anamnese estruturada como JSON
        anamnese_json = json.dumps(self.anamnese.to_dict(), ensure_ascii=False)
        return {
            'nome': self.ed_nome.text().strip(),
            'cpf': self.ed_cpf.text().strip(),
            'rg': self.ed_rg.text().strip(),
            'sexo': self.ed_sexo.text().strip(),
            'nascimento': self.ed_nasc.text().strip(),
            'telefone': self.ed_tel.text().strip(),
            'email': self.ed_email.text().strip(),
            'endereco': self.ed_end.text().strip(),
            'alergias': self.ed_alerg.text().strip(),
            'anamnese': self.tx_anamnese_livre.toPlainText().strip(),
            'anamnese_json': anamnese_json,
            'observacoes': self.tx_obs.toPlainText().strip(),
        }

    def _fill_form(self, data):
        self.ed_nome.setText(data.get('nome','') or '')
        self.ed_cpf.setText(data.get('cpf','') or '')
        self.ed_rg.setText(data.get('rg','') or '')
        self.ed_sexo.setText(data.get('sexo','') or '')
        self.ed_nasc.setText(data.get('nascimento','') or '')
        self.ed_tel.setText(data.get('telefone','') or '')
        self.ed_email.setText(data.get('email','') or '')
        self.ed_end.setText(data.get('endereco','') or '')
        self.ed_alerg.setText(data.get('alergias','') or '')
        self.tx_anamnese_livre.setPlainText(data.get('anamnese','') or '')
        self.tx_obs.setPlainText(data.get('observacoes','') or '')
        # carrega anamnese estruturada
        try:
            an = json.loads(data.get('anamnese_json') or '{}')
        except Exception:
            an = {}
        self.anamnese.from_dict(an)

    def _clear_form(self):
        self._selected_id = None
        self._fill_form({})

    def _new(self):
        self._clear_form()
        self.ed_nome.setFocus()

    def _save(self):
        data = self._read_form()
        if not data['nome']:
            QMessageBox.warning(self, 'Atenção', 'Nome é obrigatório.')
            return
        if self._selected_id is None:
            self._selected_id = self.repo.add(data)
        else:
            self.repo.update(self._selected_id, data)
        self._load_list()

    def _delete(self):
        if self._selected_id is None:
            return
        if QMessageBox.question(self, 'Confirmação', 'Excluir este paciente?') == QMessageBox.Yes:
            self.repo.delete(self._selected_id)
            self._clear_form()
            self._load_list()

    def _on_select(self, row):
        if row < 0:
            self._clear_form()
            return
        item = self.lista.item(row)
        if not item:
            return
        pid = int(item.text().split(' - ')[0])
        self._selected_id = pid
        data = self.repo.get_by_id(pid) or {}
        self._fill_form(data)

    def _open_wizard(self):
        if self._selected_id is None:
            QMessageBox.information(self, 'Atenção', 'Salve o paciente antes.')
            return
        dlg = DocumentWizard(self._selected_id, self.modelo_repo, self.lookup_repo, self.clinica_repo, self)
        dlg.exec()
