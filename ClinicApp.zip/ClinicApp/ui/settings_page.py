from PySide6.QtWidgets import QWidget, QFormLayout, QLineEdit, QPushButton, QVBoxLayout
from models.repositories import ClinicaRepo

class SettingsPage(QWidget):
    def __init__(self, clinica_repo: ClinicaRepo, parent=None):
        super().__init__(parent)
        self.repo = clinica_repo
        self._build_ui()
        self._fill()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.ed_nome = QLineEdit(); form.addRow('Nome da Clínica', self.ed_nome)
        self.ed_cnpj = QLineEdit(); form.addRow('CNPJ', self.ed_cnpj)
        self.ed_epao = QLineEdit(); form.addRow('EPAO', self.ed_epao)
        self.ed_resp = QLineEdit(); form.addRow('Responsável Técnico', self.ed_resp)
        self.ed_cro = QLineEdit(); form.addRow('CRO', self.ed_cro)
        self.ed_tel = QLineEdit(); form.addRow('Telefone', self.ed_tel)
        self.ed_email = QLineEdit(); form.addRow('Email', self.ed_email)
        self.ed_end = QLineEdit(); form.addRow('Endereço', self.ed_end)
        self.ed_cidade = QLineEdit(); form.addRow('Cidade', self.ed_cidade)
        self.ed_uf = QLineEdit(); form.addRow('UF', self.ed_uf)
        lay.addLayout(form)

        self.btn_save = QPushButton('Salvar')
        lay.addWidget(self.btn_save)
        self.btn_save.clicked.connect(self._save)

    def _fill(self):
        d = self.repo.get()
        self.ed_nome.setText(d.get('nome','') or '')
        self.ed_cnpj.setText(d.get('cnpj','') or '')
        self.ed_epao.setText(d.get('epao','') or '')
        self.ed_resp.setText(d.get('responsavel_tecnico','') or '')
        self.ed_cro.setText(d.get('cro','') or '')
        self.ed_tel.setText(d.get('telefone','') or '')
        self.ed_email.setText(d.get('email','') or '')
        self.ed_end.setText(d.get('endereco','') or '')
        self.ed_cidade.setText(d.get('cidade','') or '')
        self.ed_uf.setText(d.get('uf','') or '')

    def _save(self):
        self.repo.save({
            'nome': self.ed_nome.text().strip(),
            'cnpj': self.ed_cnpj.text().strip(),
            'epao': self.ed_epao.text().strip(),
            'responsavel_tecnico': self.ed_resp.text().strip(),
            'cro': self.ed_cro.text().strip(),
            'telefone': self.ed_tel.text().strip(),
            'email': self.ed_email.text().strip(),
            'endereco': self.ed_end.text().strip(),
            'cidade': self.ed_cidade.text().strip(),
            'uf': self.ed_uf.text().strip(),
        })
