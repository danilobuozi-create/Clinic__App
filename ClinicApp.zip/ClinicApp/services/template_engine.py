from jinja2 import Environment, BaseLoader, select_autoescape

def render_template(html: str, context: dict) -> str:
    env = Environment(loader=BaseLoader(), autoescape=select_autoescape(['html','xml']))
    tmpl = env.from_string(html)
    return tmpl.render(**context)
