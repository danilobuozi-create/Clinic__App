from weasyprint import HTML, CSS
from pathlib import Path
from typing import Optional
from config import DEFAULT_CSS_PATH

def html_to_pdf(html_str: str, output_path: Path, css_path: Optional[Path] = None) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheets = []
    if css_path and Path(css_path).exists():
        sheets.append(CSS(filename=str(css_path)))
    elif DEFAULT_CSS_PATH.exists():
        sheets.append(CSS(filename=str(DEFAULT_CSS_PATH)))
    HTML(string=html_str).write_pdf(str(output_path), stylesheets=sheets)
    return output_path
