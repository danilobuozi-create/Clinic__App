import sqlite3, json
from typing import List, Dict, Any, Optional
from config import DB_PATH

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def _rows_to_dicts(rows):
    return [dict(r) for r in rows]

# ---------------- Pacientes ----------------
class PacienteRepo:
    def add(self, data: Dict[str, Any]) -> int:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO pacientes (nome, cpf, rg, sexo, nascimento, telefone, email, endereco, alergias, anamnese, anamnese_json, observacoes, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)",
            (
                data.get('nome'),
                data.get('cpf'), data.get('rg'), data.get('sexo'),
                data.get('nascimento'), data.get('telefone'), data.get('email'),
                data.get('endereco'), data.get('alergias'),
                data.get('anamnese'),
                data.get('anamnese_json'),   # JSON string
                data.get('observacoes'),
            )
        )
        conn.commit()
        nid = cur.lastrowid
        conn.close()
        return nid

    def listar_todos(self) -> List[Dict[str, Any]]:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT * FROM pacientes ORDER BY nome")
        rows = cur.fetchall(); conn.close()
        return _rows_to_dicts(rows)

    def search_by_name(self, term: str) -> List[Dict[str, Any]]:
        term = f"%{term}%"
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT * FROM pacientes WHERE nome LIKE ? ORDER BY nome", (term,))
        rows = cur.fetchall(); conn.close()
        return _rows_to_dicts(rows)

    def get_by_id(self, pid: int) -> Optional[Dict[str, Any]]:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT * FROM pacientes WHERE id=?", (pid,))
        row = cur.fetchone(); conn.close()
        return dict(row) if row else None

    def update(self, pid: int, data: Dict[str, Any]) -> None:
        conn = get_connection(); cur = conn.cursor()
        cur.execute(
            "UPDATE pacientes SET nome=?, cpf=?, rg=?, sexo=?, nascimento=?, telefone=?, email=?, endereco=?, alergias=?, anamnese=?, anamnese_json=?, observacoes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (
                data.get('nome'),
                data.get('cpf'), data.get('rg'), data.get('sexo'),
                data.get('nascimento'), data.get('telefone'), data.get('email'),
                data.get('endereco'), data.get('alergias'),
                data.get('anamnese'),
                data.get('anamnese_json'),
                data.get('observacoes'), pid
            )
        )
        conn.commit(); conn.close()

    def delete(self, pid: int) -> None:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("DELETE FROM pacientes WHERE id=?", (pid,))
        conn.commit(); conn.close()

# ---------------- Modelos ----------------
class ModeloRepo:
    def add(self, nome: str, html: str, meta: str = "{}") -> int:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("INSERT INTO modelos (nome, html, meta) VALUES (?, ?, ?)", (nome, html, meta))
        conn.commit(); nid = cur.lastrowid; conn.close()
        return nid

    def update(self, mid: int, nome: str, html: str, meta: str = "{}") -> None:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("UPDATE modelos SET nome=?, html=?, meta=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (nome, html, meta, mid))
        conn.commit(); conn.close()

    def listar_todos(self) -> List[Dict[str, Any]]:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT * FROM modelos ORDER BY nome")
        rows = cur.fetchall(); conn.close()
        return _rows_to_dicts(rows)

    def get_by_id(self, mid: int) -> Optional[Dict[str, Any]]:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT * FROM modelos WHERE id=?", (mid,))
        row = cur.fetchone(); conn.close()
        return dict(row) if row else None

    def find_by_name(self, starts_with: str) -> Optional[Dict[str, Any]]:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT * FROM modelos WHERE nome LIKE ? ORDER BY id LIMIT 1", (starts_with+'%',))
        row = cur.fetchone(); conn.close()
        return dict(row) if row else None

    def delete(self, mid: int) -> None:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("DELETE FROM modelos WHERE id=?", (mid,))
        conn.commit(); conn.close()

# ---------------- Documentos ----------------
class DocumentoRepo:
    def add(self, paciente_id: int, modelo_id: Optional[int], parametros: Dict[str, Any], caminho_pdf: str, data_criacao: str) -> int:
        conn = get_connection(); cur = conn.cursor()
        cur.execute(
            "INSERT INTO documentos (paciente_id, modelo_id, parametros, caminho_pdf, data_criacao) VALUES (?, ?, ?, ?, ?)",
            (paciente_id, modelo_id, json.dumps(parametros, ensure_ascii=False), caminho_pdf, data_criacao)
        )
        conn.commit(); nid = cur.lastrowid; conn.close()
        return nid

    def listar_todos(self) -> List[Dict[str, Any]]:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("""
            SELECT d.*, p.nome AS paciente_nome, m.nome AS modelo_nome
            FROM documentos d
            LEFT JOIN pacientes p ON p.id=d.paciente_id
            LEFT JOIN modelos m ON m.id=d.modelo_id
            ORDER BY datetime(data_criacao) DESC
        """)
        rows = cur.fetchall(); conn.close()
        return _rows_to_dicts(rows)

# ---------------- Lookups ----------------
class LookupRepo:
    def add(self, tipo: str, codigo: str, descricao: str) -> int:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("INSERT INTO lookups (tipo, codigo, descricao) VALUES (?, ?, ?)", (tipo, codigo, descricao))
        conn.commit(); nid = cur.lastrowid; conn.close()
        return nid

    def listar_por_tipo(self, tipo: str) -> List[Dict[str, Any]]:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT * FROM lookups WHERE tipo=? ORDER BY descricao", (tipo,))
        rows = cur.fetchall(); conn.close()
        return _rows_to_dicts(rows)

    def delete(self, lid: int) -> None:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("DELETE FROM lookups WHERE id=?", (lid,))
        conn.commit(); conn.close()

# ---------------- Clínica ----------------
class ClinicaRepo:
    def get(self) -> Dict[str, Any]:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("SELECT * FROM clinica WHERE id=1")
        row = cur.fetchone(); conn.close()
        return dict(row) if row else {}

    def save(self, data: Dict[str, Any]) -> None:
        conn = get_connection(); cur = conn.cursor()
        cur.execute("""UPDATE clinica SET
            nome=?, cnpj=?, epao=?, responsavel_tecnico=?, cro=?, telefone=?,
            email=?, endereco=?, cidade=?, uf=?, updated_at=CURRENT_TIMESTAMP
            WHERE id=1""",
            (data.get('nome'), data.get('cnpj'), data.get('epao'), data.get('responsavel_tecnico'),
             data.get('cro'), data.get('telefone'), data.get('email'), data.get('endereco'),
             data.get('cidade'), data.get('uf'))
        )
        conn.commit(); conn.close()
